# Steganography_Using_Java
The purpose of the project is to hide the information over a picture utilizing steganographic algorithm and compare different techniques of hiding data using the encryption module of this task in the invisible steganography domain.
